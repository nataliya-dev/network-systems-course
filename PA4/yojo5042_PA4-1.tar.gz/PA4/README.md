## build
### DFS
- `make` in the dfs directory
### DFC
- `make` in the dfc directory

## run
## dfs server
- you can use the `start_dfs.sh` script
- `DFS[1-4]` directories are there
- some test files too

## dfc server
- `./dfc dfc.conf` in the `dfc` directory